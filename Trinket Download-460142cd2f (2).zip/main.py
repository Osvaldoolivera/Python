# variables
i1 = 33
i2 = 48
i3 = 65
i4 = 65+25
i5 = 97
#output
print("integers")
print(i1,i2,i3,i4,i5)
c1 = chr(i1)
c2 = chr(i2)
c3 = chr(i3)
c4 = chr(i4)
c5 = chr(i5)
print("characters")
print(c1,c2,c3,c4,c5)

